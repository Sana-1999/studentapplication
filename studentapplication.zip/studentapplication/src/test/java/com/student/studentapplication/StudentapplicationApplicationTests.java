package com.student.studentapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
