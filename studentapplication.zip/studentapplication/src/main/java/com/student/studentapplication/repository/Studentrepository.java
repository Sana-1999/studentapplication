package com.student.studentapplication.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.student.studentapplication.entity.Student;

public interface Studentrepository extends JpaRepository<Student, Integer>{
	
	

}
